# Privacy and data flow

The generic distribution is intentionally limited to public discovery and
local bundle-building workflows.

## Data flow

- Public discovery inputs and bounded public catalog reads may travel between
  the host and the App Hub remote MCP endpoint.
- Bundle Builder local files remain on the user's host during local creation
  and packaged validation.
- Remote validation is opt-in and task-scoped. Before sending anything,
  disclose the purpose (public-source bundle validation), destination (the App
  Hub remote validator), and categories selected (the exact bundle metadata,
  manifest, and source files needed for that validation). Obtain new consent if
  those categories or the purpose materially expand.
- Remote validation does not persist submitted source content. Results remain
  bounded and must not be copied into unrelated prompts, telemetry, or logs.

## Retention and telemetry

The package makes no claim about a host's retention. Hosts must apply their own
retention controls and the App Hub service's documented policy. Optional App
Hub telemetry is opt-out aware and limited to sanitized, ephemeral, or hashed
metadata. Prompts, source artifacts, credentials, raw identifiers, and raw
errors are not permitted telemetry values.

## Forbidden inputs

Never enter a Torizon Cloud Client Secret, raw credential, access token,
private key, or undisclosed remote-transfer instruction into a Skill, MCP
prompt, configuration, diagnostic, or adapter. Use first-party App Hub
credential setup for any future authenticated workflow; this generic public
package does not request those values.

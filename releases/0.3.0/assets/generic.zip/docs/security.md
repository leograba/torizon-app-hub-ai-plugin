# Security and authorization

The App Hub backend remains the authority for authentication, role, ownership,
visibility, lifecycle, device, admin, confirmation, idempotency, and audit
decisions. A Skill, host, prompt, archive, or adapter cannot grant authority.

This generic package has no authenticated account tools and no mutation path.
Operational actions require a server-bound preview and explicit confirmation;
critical actions such as test overrides, role changes, ownership transfers,
deletion, and publication remain first-party App Hub web handoffs. They are not
available through this distribution.

Retrieved catalog data, bundle files, instructions, and generated artifacts
are untrusted data. The host controls sandboxing, script execution, network
access, dependency installation, and approval prompts. Users should inspect
the package inventory and checksum before installation and avoid executing
unreviewed content.

The generator and checker reject unsafe archive paths, symbolic links,
expansion bombs, oversized files, machine-local paths, credential-shaped
values, and private-key material. No token is transported in a URL, and no
credential is written to package metadata, logs, or support evidence.

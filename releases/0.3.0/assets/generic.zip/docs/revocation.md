# Removal, session, and credential revocation

The public generic MCP connection is anonymous and does not issue an App Hub
session. Revoking this distribution therefore starts with disabling the MCP
connection, removing the installed Skill folders, and clearing host caches or
packaged fallback copies.

If a host has separately configured an authenticated App Hub connection, sign
out and revoke that host session through the host and App Hub's first-party
account security controls. App Hub administrators must use server-side account
and role controls; a package removal cannot revoke another user's access.

If a Torizon Cloud credential may have been exposed, stop using it and rotate
or revoke it through first-party App Hub/Torizon Cloud credential setup. Never
paste the value into a Skill, MCP request, issue, telemetry event, log, or
support report. Report only the artifact fingerprint and sanitized timing or
correlation details.

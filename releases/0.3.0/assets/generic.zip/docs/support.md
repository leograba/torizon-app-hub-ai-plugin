# Support and recovery

This release is an experimental, unsigned, marketplace-independent candidate.
It is source-implemented and locally conformant only; it is not deployment
verified, marketplace ready, or covered by a recorded human release approval.

When requesting support, provide only the product version, contract versions,
artifact filename, SHA-256 fingerprint, host name/version, and a sanitized
description of the problem. Do not provide bundle contents, prompts, emails,
tokens, credentials, private keys, or raw server errors.

The distribution index is the canonical support reference. It may show a
source-implemented candidate with pending approval or host evidence; that
state must not be described as publication, signing, deployment verification,
or official marketplace availability.

For a failed installation or validation, use these recovery actions in order:

1. Re-run the checksum verification and re-extract a clean copy.
2. Compare the host's installed Skill scope and MCP endpoint with the release
   manifest and compatibility document.
3. Use the packaged local validator and disclosed stale fallback when the
   remote service is unavailable; do not claim current catalog state from it.
4. Remove the package and revoke any separately configured host session if
   compromise or unauthorized access is suspected.

Record sanitized correlation information from the host or App Hub support
flow only. A support report never authorizes a write or a critical action.

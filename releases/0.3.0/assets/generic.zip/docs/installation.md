# Generic distribution installation

This package is the marketplace-independent Torizon App Hub public
experimental distribution. It provides public, read-only MCP discovery plus
portable App Discovery Advisor and Bundle Builder Skills. It does not install
authenticated account access, operational writes, administrative tools, or
critical-action executors.

## App Hub customer entry point

Customers should begin at the App Hub AI Plugin distribution entry point and
choose their journey (discover/deploy or build/submit) and host. Codex and
Claude Code are the supported custom-channel paths. This generic package is a
reduced fallback for hosts without an approved custom channel; it is not an
official Claude or OpenAI marketplace listing and does not provide capability
parity with those host channels.

The generated distribution index is the release record for the three paths.
It identifies the canonical plugin, release family, checksums, provenance,
approval state, compatibility, capability boundary, support, and revocation
guidance. A source-implemented candidate is not a published or approved
customer release until its approval and host evidence are recorded.

## Codex custom channel

1. Open the App Hub AI Plugin installation page and select **Codex**.
2. Open only the immutable channel source shown for the approved release, then
   add that source through the host's custom marketplace flow.
3. Install `torizon-app-hub` from that channel. Do not add a second standalone
   `torizon-app-hub` MCP entry.
4. Start a fresh Codex session. Use `codex mcp login torizon-app-hub` when
   private App Hub capabilities are needed; this starts the host-managed
   delegated OAuth flow.
5. Verify a low-risk public discovery task before relying on account-scoped
   capabilities.

For an update, use the host-supported channel update or reinstall path and
start a fresh session again. For removal, log out and remove the
`torizon-app-hub` MCP entry, then remove the plugin and custom channel. If an
older standalone entry exists, log out and remove it before installing the
custom-channel package so host precedence and callback configuration do not
conflict.

## Claude Code custom channel

1. Open the App Hub AI Plugin installation page and select **Claude Code**.
2. Open only the immutable channel source shown for the approved release and
   add it through Claude Code's custom marketplace flow.
3. Install `torizon-app-hub` at the desired host scope. Do not add a second
   standalone App Hub MCP entry.
4. Start a fresh Claude Code session. Use the host's `/mcp` flow to connect
   `torizon-app-hub` when private App Hub capabilities are needed; OAuth is
   host-managed and no secret belongs in this package.
5. Verify a low-risk public discovery or local bundle task before relying on
   account-scoped capabilities.

For an update, use the host-supported marketplace update or reinstall path and
start a fresh session again. For removal, log out and remove the
`torizon-app-hub` MCP entry, then uninstall the plugin and remove the custom
channel. If an older standalone entry exists, log out and remove it before
installing the custom-channel package.

In both custom channels, installation, a fresh session, OAuth connection, and
capability verification are separate states. App Hub cannot claim that a local
host installation or OAuth flow completed merely because the customer opened a
channel link.

## Verify before installing

1. Obtain the release directory and its `SHA256SUMS` file from the same
   approved source.
2. Run `sha256sum -c SHA256SUMS` from that directory.
3. Inspect `stage/inventory.json`, `stage/release-manifest.json`, and the
   package documents before extracting a Skill or configuring MCP.
4. Keep the artifact version and checksum available for support or rollback.

The aggregate `torizon-app-hub-public.zip` contains the complete inspectable
package. The two individual `.skill` archives are convenient copies of the
portable Skills and have the same release metadata and provenance boundary.

## Configure the generic MCP connection

Use `stage/mcp-connection.json` as the host-neutral connection inventory. The
endpoint is resolved from `MCP_RESOURCE_URI`; the release candidate defaults to
the public HTTPS path `https://tznapphub.link/mcp` when that environment value
is not overridden by an operator.

This public connection is anonymous and exposes only the bounded public
capabilities listed in the release manifest. Do not add credentials, tokens,
query-string secrets, or a server command to this package. Authenticated
capabilities require a separately approved host configuration and are not
implicitly enabled by installing these files.

## Install the Skills

Extract the individual Skill archive, or copy its Skill folder, into the
host's documented Skill directory at the desired user/project scope. Preserve
the archive's relative root and packaged assets. Hosts decide the exact install
location, sandbox, dependency policy, and execution approvals; this package
does not override those controls.

The Bundle Builder can work locally with its packaged schema, examples, tags,
and validator fallback. Remote validation is optional and requires the
task-scoped consent disclosure in `docs/privacy.md` before selected content is
sent to App Hub.

## Remove the installation

Disable or remove the MCP connection and delete the installed Skill folders
using the host's normal uninstall flow. Clear host caches or copied fallback
snapshots when removing the package. Removal does not publish, delete, or
change an App Hub bundle.

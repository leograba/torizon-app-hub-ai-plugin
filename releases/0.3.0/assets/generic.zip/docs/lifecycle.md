# Rollback, deprecation, and incident response

Channel lifecycle is independent. Hiding or revoking an affected Codex,
Claude Code, or generic channel does not revoke unrelated App Hub OAuth grants
or remove another host's installation. Use the distribution index to identify
the channel, release family, approval state, checksum, and revocation record
before changing a customer installation.

## Rollback

The generic package has no automatic update mechanism. To roll back, disable
the current MCP connection, remove the current Skill folders, install a
previous release from the approved artifact source, and verify its exact
SHA-256 checksum before use. Record the restored product and contract versions.
Do not mix files from releases or use a prior fallback with an incompatible
schema or validator major.

Rollback changes the local host installation only. It cannot publish, delete,
edit, transfer, or otherwise mutate App Hub state.

## Deprecation

Deprecating a capability or package requires a release note, replacement or
migration guidance, a compatibility window, and a final removal version. A
stable canonical capability ID is never reused. Deprecated IDs remain aliases
while their compatibility window is supported; hosts should migrate before
the removal version. The legacy `bundle-assembler` download remains a separate
compatibility alias until its documented retirement gate is satisfied.

## Incident response

For suspected compromise, remove the package, disable its MCP connection,
revoke any separately configured host session, and report only sanitized
version, checksum, host, and correlation details. Rotate credentials through
first-party account controls. Preserve the package checksum and release
manifest for investigation, but never preserve or transmit the exposed value.

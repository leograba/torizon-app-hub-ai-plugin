# Torizon App Hub canonical plugin contract

This directory is the canonical AI plugin source boundary. The complete release
includes every implemented public, authenticated, contributor, operational,
Admin, and first-party critical-handoff capability on every technically
applicable adapter; a public read-only projection is development evidence, not
an acceptable release substitute. Direct installation is the supported
distribution path, while marketplace-grade package and conformance checks keep
each adapter continuously publishable. This directory does not replace the
current `skills/bundle-assembler` download. The authenticated App Hub contributor
download packages the canonical Bundle Builder and Bundle Maintainer Skills;
the deployed legacy URL remains a live compatibility alias until contributor
hosted equivalence and release gates are satisfied.

- `plugin.manifest.json` is the host-neutral capability and packaging inventory.
- `plugin.manifest.schema.json` is its versioned JSON Schema.
- `mcp/schemas/` is the canonical Draft 2020-12 MCP domain contract at revision
  `0.4.0`; `mcp/examples/` contains network-free representative fixtures.
- `contracts/` is the independently owned workspace for the strict schema
  registry, semantic graph rules, black-box target harness, and contract tests.
- `compatibility/evidence.json` and `governance/control-coverage.json` are the
  structured evidence and assertion-coverage sources. Reference fixtures remain
  model evidence; the independent Fastify-injection target and official SDK
  client release check provide local runtime conformance only.
- `compatibility/evidence.json` is the preserved compatibility evidence for the
  contributor workflow
  matrix/runbook. It keeps local conformance, hosted runner readiness,
  authenticated deployment evidence, host evaluation, and release approval as
  separate statuses.
- `skills/` contains the portable App Discovery Advisor, Deployment Copilot,
  Bundle Builder, Bundle Maintainer, Review & Publishing Copilot, Ecosystem
  Operations, and Connection & Safety Skills. Deployment Copilot is an
  authenticated experimental Skill and is excluded from the generic public
  distribution.
- `validator/` exposes the `2.0.0` authoritative browser, Node, and portable
  behavioral entrypoints and builds the
  dependency-bundled Node fallback shared with frontend validation.
- The Fastify backend mounts the mixed-mode Streamable HTTP endpoint at `/mcp`.
  Anonymous clients retain public discovery, while the locally
  implemented authenticated account resources and contributor Bundle Maintainer
  portfolio/lifecycle/test resources and tools require Cognito access tokens;
  `MCP_RESOURCE_URI` supplies the canonical deployment URL and the
  App Hub-owned protected-resource metadata identity. contributor source/runtime
  evidence is local only until the separate hosted OAuth, deployment, host,
  and release gates are satisfied.
- The AI Plugin OpenSpec capabilities under `openspec/specs/ai-plugin-*/` define
  normative behavior, while `plugin.manifest.json` and its schemas define the
  machine-readable inventory and contract. Repository installation and
  operational guidance remains in the root `README.md` and `.ai/rules.md`.

Generated adapter artifacts must be deterministic, inspectable, and build-only.
They may translate the manifest for a host, but they may not change canonical
capabilities, authorization, privacy, confirmation, or domain behavior.

Build and verify the generic candidate with
`pnpm check:ai-plugin-distribution`. Output is written beneath ignored
`artifacts/ai-plugin/generic/` and contains individual Skill archives, the MCP
connection inventory, release-specific manifest/schema, separated canonical
provenance, package-local privacy/security/support/installation/revocation and
lifecycle documents, a marketplace-independent acceptance-test manifest,
per-file inventory, checksums, and an unsigned aggregate archive. The build
runs twice in clean temporary directories with pinned `fflate` and rejects
non-identical bytes, unsafe paths, secret-shaped content, expansion bombs, or
unexpected files. The checker validates all 12 local acceptance cases without
marketplace tooling. The generic public packages contain no authenticated or
mutation tools and are explicitly not deployment-verified, signed, or
marketplace-ready. The source runtime's authenticated resources are
not included in that generic distribution until the separate release gate
approves them.

Build the local, conditional OpenAI ChatGPT adapter package with
`pnpm build:ai-plugin:openai -- --local` and verify it with
`pnpm check:ai-plugin:openai`. The generator reads only the canonical manifest
and MCP schemas, emits ignored build-only artifacts beneath
`artifacts/ai-plugin/openai-chatgpt/`, and does not require filesystem Skills.
For a hosted-configured dry run, provide `MCP_RESOURCE_URI` and an exact
`OPENAI_CHATGPT_OAUTH_CALLBACK_URL` matching the pre-registered public PKCE
client; this still does not claim deployment, clean installation, or a real
ChatGPT host result. Set `MCP_ADAPTER_SURFACE=openai-chatgpt` only
when the backend must project the OpenAI compatibility aliases; generic MCP
remains the default and retains the canonical standard metadata.

Build and verify the local, conditional OpenAI Codex/filesystem plugin package
with `pnpm build:ai-plugin:codex` and `pnpm check:ai-plugin:codex`. The generator
reads the canonical manifest, adapter metadata, and selected Skill trees without
network access and emits ignored build-only artifacts beneath
`artifacts/ai-plugin/openai-codex/`: a valid `.codex-plugin/plugin.json` package,
portable App Hub Skills, a plugin-provided `.mcp.json` for the canonical
hosted endpoint, capability/privacy/safety/provenance and reviewer-test
material, a repo-local marketplace fixture, a ZIP, inventories, and checksums.
It deliberately does not emit `.app.json`, hooks, credentials, or critical
action executors. Installation configures the MCP entry, but delegated OAuth
remains explicit and per-user; direct installation, complete remote MCP
capability coverage, and fresh-thread host behavior remain separate release
gates. The external `skills-ref` validator is not silently installed and its
gap is recorded in the package provenance.

Hosted plugin builds validate these explicit public inputs and fail closed on
missing or mismatched values: `MCP_RESOURCE_URI`,
`CODEX_MCP_CLIENT_ID`, `CODEX_MCP_CALLBACK_URL`,
`CODEX_MCP_CALLBACK_PORT`, `CLAUDE_CODE_MCP_CLIENT_ID`, and
`CLAUDE_CODE_MCP_CALLBACK_PORT`. Local deterministic tests provide explicit
fixtures; no client secret or bearer token is accepted.

Build and verify the local, conditional Anthropic Claude adapter projections
with `pnpm build:ai-plugin:anthropic` and `pnpm check:ai-plugin:anthropic`. The
generator reads the canonical manifest, MCP contracts, adapter sources, and
selected Skill trees without network access and emits ignored build-only
artifacts beneath `artifacts/ai-plugin/anthropic/`. The remote Connector
materials include current OAuth/HTTPS declarations, tool/resource/prompt
inventories, required annotations, directory listing fields, privacy/safety/
support disclosures, reviewer-account requirements, conformance cases, and
checksums, but no endpoint, token, or credential. The Claude Code package ships
the canonical Skills plus a self-contained `.claude-plugin/plugin.json`,
plugin-root `.mcp.json`, repo-local marketplace fixture, and deterministic
ZIP. Its public client and callback port configure the hosted endpoint without
embedding a secret; delegated OAuth remains explicit and per-user. Hosted
custom-Connector OAuth, direct Claude Code installation, complete remote MCP
capability coverage, platform validation, and real-host behavior remain release
gates. Directory or community submission, platform approval, and separate
human approval do not.

Run the local contributor conformance harness with
`pnpm check:ai-plugin:contributor:local`. The separate hosted smoke runner is
`pnpm check:mcp:contributor:remote`; without an operator token it is a no-network
`Conditional` dry run. Hosted draft writes, synthetic remote validation, and
confirmed edit retries require the explicit consent and write flags documented
in `compatibility/evidence.json`.

Run the cross-platform security local security and release harness with
`pnpm check:ai-plugin:cross-platform-security:local`. It is deterministic, offline, synthetic-only,
preview-only, and emits a versioned sanitized JSON report. The corpus covers the
canonical graph, all adapter projections, prompt-injection sources, secret/PII
surfaces, consent and telemetry, role/tenant/visibility boundaries, write
confirmation, Torizon cooldown/backoff, archive red-team cases, and both
recommended release stories.

The gated hosted readiness runner is
`pnpm check:ai-plugin:cross-platform-security:hosted`. It is a no-network dry run by default and
reports `Conditional` without operator inputs. An operator must supply a
short-lived token, an HTTPS `/mcp` endpoint, the exact
`task-scoped-synthetic-only` consent value, and disposable fixture identifiers
before `--live` can probe the host. The corresponding environment variables are
`APP_HUB_CROSS_PLATFORM_SECURITY_OPERATOR_TOKEN`, `APP_HUB_CROSS_PLATFORM_SECURITY_ENDPOINT`,
`APP_HUB_CROSS_PLATFORM_SECURITY_CONSENT`, and `APP_HUB_CROSS_PLATFORM_SECURITY_FIXTURES`; fixture
identifiers must include `synthetic-account`, `synthetic-bundle`,
`synthetic-version`, `synthetic-device`, and `synthetic-draft`.
`--allow-disposable-writes` is an additional explicit gate; it never turns on
writes by itself, and no hosted evidence is inferred for OAuth, deployment,
model-host evaluation or clean direct-install evidence.

`release-profiles/source-implemented.md` is generated from the canonical
manifest and selected release profile. `pnpm check:ai-plugin-release-docs`
fails on drift. Package outputs place SBOM, provenance, signature status,
revocation metadata, and immutable-run binding under `evidence/`; a local build
without `AI_PLUGIN_BUILD_EVIDENCE` remains explicitly unverified, and signing
requires operator-supplied `AI_PLUGIN_SIGNING_KEY_FILE` and
`AI_PLUGIN_SIGNING_KEY_ID`.

## Hosted verification

`pnpm check:hosted:fixtures` validates the strict synthetic/disposable fixture
inventory and hosted verification evidence envelope. `pnpm check:mcp:admin-operations:remote` is
network-free and blocked by default; an actual run requires a short-lived Admin
token and explicit bundle/version references. Operational writes additionally
require both `MCP_ADMIN_OPERATIONS_REMOTE_ALLOW_WRITE=1` and
`MCP_ADMIN_OPERATIONS_REMOTE_DISPOSABLE_FIXTURE=1`. The five critical executors are
asserted absent and only first-party handoff preparation is exercised.

`pnpm e2e:hosted` runs the dedicated public hosted browser smoke against the
existing `https://tznapphub.link` deployment. Authenticated browser scenarios
remain separately gated by disposable credentials and must write sanitized
reports under the ignored `artifacts/hosted/` boundary.

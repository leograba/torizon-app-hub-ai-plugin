# Canonical MCP schemas

This directory contains the host-neutral App Hub domain contract for MCP
revision `0.4.0`. Every schema is Draft 2020-12 and uses a stable
`https://schemas.torizon.dev/apphub/mcp/0.4.0/...` `$id`; payloads use the shared
`schemaVersion: "0.4.0"` definition from `common/common.schema.json`.

- `common/` contains bounded metadata, visibility, freshness, common envelopes,
  identifiers, and bounded authored/sanitized domain summaries. Length bounds
  do not imply runtime sanitization.
- `resources/`, `tools/`, and `prompts/` contain the typed public contract
  entries listed in `plugin.manifest.json`.
- `pagination/` defines opaque cursor requests, bounded responses, and the
  server-side five-minute cursor binding.
- `errors/` defines post-authorization domain errors; HTTP authentication and
  MCP JSON-RPC transport envelopes are intentionally out of scope.
- `audit/` defines allowlisted, closed security, operation, and telemetry event
  shapes; runtime DLP is still required immediately before persistence.
- `operations/` defines idempotency policy, one-use preview handles, and
  bounded operation metadata.

The manifest is the inventory and the JSON Schemas are the payload authority.
Marketplace adapters may reference or project these contracts, but may not
override authorization, risk, confirmation, annotations, data classification,
or domain behavior.

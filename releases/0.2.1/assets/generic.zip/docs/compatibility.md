# Compatibility matrix and versioning

The generic release uses Semantic Versioning. The product and each projected
contract are recorded in `stage/release-manifest.json`; the canonical source
manifest remains the source of truth.

| Surface | Version | Accepted range | Authentication | Fallback | Local release status |
| --- | --- | --- | --- | --- | --- |
| Torizon App Hub product release | `0.2.1` | `~0.2.1` | Depends on projected surface | See the selected profile | Experimental |
| Generic MCP contract | `0.4.0` | `~0.4.0` | Anonymous public surface | None for current data | Experimental |
| App Discovery Advisor Skill contract | `0.1.0` | `~0.1.0` | Host-local plus public MCP when available | Text-only public guidance; stale disclosure required | Experimental |
| Bundle Builder Skill contract | `0.1.0` | `~0.1.0` | Host-local; remote validation is separately consented | Packaged schema, examples, tags, and validator `2.0.0` | Experimental |
| Packaged validator | `2.0.0` | `^2.0.0` | None | Local fallback for compatible bundle schemas | Locally verified |

Additive capability or disclosure changes use a minor version; fixes and
documentation-only changes use a patch version. While the MCP contract is
below `1.0.0`, an explicitly documented breaking contract, authorization,
safety, or behavior change may use a minor version; after `1.0.0`, it requires
a major version. Deprecated capability IDs are never reused and retain an
alias during the documented migration window.

This matrix describes local compatibility only. It does not prove a host's
installation support, deployment state, OAuth behavior, marketplace review,
or human approval.
